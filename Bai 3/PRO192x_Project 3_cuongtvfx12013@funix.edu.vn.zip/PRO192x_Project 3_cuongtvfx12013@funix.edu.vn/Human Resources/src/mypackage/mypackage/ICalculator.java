package mypackage;
public interface ICalculator {
   public abstract long calculateSalary();
}
